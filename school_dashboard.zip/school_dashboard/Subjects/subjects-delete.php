<?php include '../dp.php';


$id=$_GET['id'];

$sql = "DELETE FROM subjects WHERE id=$id";
if (mysqli_query($conn,$sql)) {
    header("Location:subjects.php");
}else{
    echo "Error: ". "<br>". mysqli_error($conn);
}

?> 