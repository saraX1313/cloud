<?php include 'dp.php'; 
header('Content-Type: application/json charset=utf-8');

if ($conn->connect_error){
    echo json_encode(["success"=>false,"massage"=>"connection failed: " . $conn->connect_error]);
    exit();
}
$data=[];
function fetchTableData($conn,$tablename){
    $sql = "SELECT * FROM $tablename";
    $result= $conn->query($sql);

    if ($result->num_rows >0) {
        $rows=[];
        while($row=$result->fetch_assoc()) {
        $rows[]=$row;
        }
        return $rows;
    }else{
        return [];
    }
}

$data['classes'] = fetchTableData($conn,'classes');
$data['teachers'] = fetchTableData($conn,'teachers');
$data['students'] = fetchTableData($conn,'students');
$data['subjects'] = fetchTableData($conn,'subjects');
$data['teacher_student'] = fetchTableData($conn,'teacher_student');
$data['users']=fetchTableData($conn,'users');

echo json_encode(["success"=>true,"data"=>$data]);

$conn->close();
?>