<?php include '../dp.php';

if($_SERVER ['REQUEST_METHOD'] === 'POST'){
    $name=$_POST['name'];
    
    $sql="INSERT INTO subjects (name) VALUES ('$name')";
    if (mysqli_query($conn,$sql)) {
        header("Location:subjects.php");
    }else{
        echo "Error: ". "<br>". mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> mange subjects</title>
    <link rel="stylesheet"  href="../style.css">
</head>
<body>
    <div class='sidebar'>
        <h1>school dashboard</h1>
        <ul>
            <li><a href="../Students/students.php">students</a></li>
            <li><a href="../classes.php">classes</a></li>
            <li><a href="subjects.php">subjects</a></li>
            <li><a href="../Teachers/teachers">teachers</a></li>
        </ul>
    </div>
    <div class='content'>
        <h1>mange subjects</h1>
        <form action="" method="POST">
        <label for="name">subjects Name:</label>
        <input type="text" name="name" id="name" required><br>
            <button type="submit">add subjects</button>
        </form>
    </div>
</body>
</html>