<?php
include '../dp.php';

$classes = mysqli_query($conn, "SELECT id, name FROM classes");
$teachers = mysqli_query($conn, "SELECT id, name FROM teachers");

$id = $_GET['id'];
$student_result = $conn->query("SELECT * FROM students WHERE id = $id");
$student = $student_result->fetch_assoc();

$teacher_student_result = $conn->query("SELECT * FROM teacher_student WHERE student_id = $id");
$teacher_student = $teacher_student_result->fetch_assoc();

if (!$student) {
    echo "Error: " . mysqli_error($conn);
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $class_id = $_POST['class_id'];
    $teacher_id = $_POST['teacher_id'];

    $image = $_POST['image'];
    if (!empty($_FILES['image']['name'])) {
        $upload_dir = "../uploads/";
        $image = $_FILES['image']['name'];
        $target = $upload_dir . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    }
    
    $student = "
        UPDATE students 
        SET name = '$name', email = '$email', phone = '$phone', image = '$image', class_id = '$class_id' 
        WHERE id = $id";
    if (mysqli_query($conn, $student)===true) {
        $teacher_student = "
            UPDATE teacher_student 
            SET teacher_id = '$teacher_id' 
            WHERE student_id = $id";
        mysqli_query($conn, $teacher_student);
        
        header("Location: students.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../style.css">
    <title>Edit Student</title>
    <style>
        form {
            width: 60%;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input, select, button {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            font-weight: bold;
        }
        img {
            display: block;
            margin: 10px 0;
            max-width: 100px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class='sidebar'>
        <h1>School Dashboard</h1>
        <ul>
            <li><a href="students.php">Students</a></li>
            <li><a href="../classes.php">Classes</a></li>
            <li><a href="../Subjects/subjects.php">Subjects</a></li>
            <li><a href="../Teachers/teachers.php">Teachers</a></li>
        </ul>
    </div>
    <div class='content'>
        <h1 style="text-align: center;">Edit Student</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $id; ?>">

            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo isset($student['name'])? $student['name']: '';?>"  required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo isset($student['email'])? $student['email']: '';?>" required>
            
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" value="<?php echo isset($student['phone'])? $student['phone']: '';?>" required>
            
            <label for="image">Image:</label>
            <input type="file" name="image" id="image">
            
            <?php if (!empty($student['image'])): ?>
                <img src="../uploads/<?= $student['image']; ?>" alt="Student Image">
            <?php endif; ?>

            <label for="class_id">Class:</label>
            <select id="class_id" name="class_id" required>
                <option value="">Select Class</option>
                <?php while ($class = mysqli_fetch_assoc($classes)): ?>
                    <option value="<?= $class['id']; ?>" <?php echo isset($student['class_id']) && $student['class_id'] == $class['id'] ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($class['name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="teacher_id">Teacher:</label>
            <select id="teacher_id" name="teacher_id" required>
                <option value="">Select Teacher</option>
                <?php while ($teacher = mysqli_fetch_assoc($teachers)): ?>
                    <option value="<?= $teacher['id']; ?>" <?php echo isset($teacher_student['teacher_id']) && $teacher_student['teacher_id'] == $teacher['id'] ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($teacher['name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <button type="submit">Update Student</button>
        </form>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>