<?php include '../dp.php';


$id=$_GET['id'];

$sql = "DELETE FROM teachers WHERE id=$id";
if (mysqli_query($conn,$sql)) {
    header("Location:teachers.php");
}else{
    echo "Error: ". "<br>". mysqli_error($conn);
}

?> 