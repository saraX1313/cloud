<?php include 'dp.php'; 

$student_per_class_result = mysqli_query($conn,
    "SELECT classes.name AS class_name, COUNT(students.id) AS students_count 
     FROM students 
     JOIN classes ON students.class_id = classes.id
     GROUP BY students.class_id"
);

$class = [];
$student_per_class = [];
while($row = mysqli_fetch_assoc($student_per_class_result)){
    $class[] = $row['class_name']; 
    $student_per_class[] = $row['students_count'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="style.css">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .chart-container {
            width: 95%;
            max-width: 1200px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #4CAF50;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class='sidebar'>
        <h1>school dashboard</h1>
        <ul>
            <li><a href="./Students/students.php">students</a></li>
            <li><a href="classes.php">classes</a></li>
            <li><a href="./Subject/subjects.php">subjects</a></li>
            <li><a href="./Teachers/teachers.php">teachers</a></li>
            <li><a href="login.php">login</a></li>
            <li><a href="register.php">regsiter</a></li>
        </ul>
    </div>
    <div class='content'>
        <h1>Welcome to the dashboard</h1>
        <div class="chart-container">
            <h2>Number of students per class</h2>
            <canvas id="studentsperclasschart"> </canvas>
        </div>
    </div>

    <script>
        var ctx1 = document.getElementById('studentsperclasschart');
        var studentsperclasschart= new Chart(ctx1,{
            type: 'bar',
            data:{
                labels: [<?php echo '"' . implode('","',$class) . '"';?>],
                datasets:[{
                    label: 'number of Students',
                    data: [<?php echo implode(',', $student_per_class)?>],
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',

                    borderColor: 'rgba(255, 255, 255, 0)',
                    borderwidth: 2
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                responsive:true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Number of students per class'
                    }
                }
            }
        });


        // var ctx2 = document.getElementById('studentsperclasschart');
        // var  studentsperclasschart= new Chart(ctx2,{
        //     type: 'pie',
        //     data:{
        //         labels: [<?php echo '"' . implode('","',$class) . '"';?>],
        //         datasets:[{
        //             label: 'number of Students',
        //             data: [<?php echo implode(',', $student_per_class)?>],
        //             backgroundColor: ['red' ,'green' ,'blue', 'gray' ,'black'],
        //             hoveroffset: 4
        //         }]
        //     },
        //     options: {
        //         responsive:true,
        //         plugins: {
        //             title: {
        //                 display: true,
        //                 text: 'Number of students per class'
        //             }
        //         }
        //     }
        // });
    </script>
</body>
</html>