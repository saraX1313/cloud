 <?php include 'dp.php';


    $id=$_GET['id'];
    
    $sql = "DELETE FROM classes WHERE id=$id";
    if (mysqli_query($conn,$sql)) {
        header("Location:classes.php");
    }else{
        echo "Error: ". "<br>". mysqli_error($conn);
    }

?> 