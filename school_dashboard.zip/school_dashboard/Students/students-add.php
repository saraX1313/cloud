<?php include '../dp.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../style.css">
    <title>Add Student</title>
    <style>
        form {
            width: 60%;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input, select, button {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class='sidebar'>
        <h1>School Dashboard</h1>
        <ul>
            <li><a href="students.php">Students</a></li>
            <li><a href="../classes.php">Classes</a></li>
            <li><a href="../Subjects/subjects.php">Subjects</a></li>
            <li><a href="../Teachers/teachers.php">Teachers</a></li>
        </ul>
    </div>
    <div class='content'>
        <h1 style="text-align: center;">Add Student</h1>
        <?php

        $classes = mysqli_query($conn, "SELECT id, name FROM classes");
        $teachers = mysqli_query($conn, "SELECT id, name FROM teachers");
        
        $upload_dir = "../uploads/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);  
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $class_id = $_POST['class_id'];
            $teacher_id = $_POST['teacher_id'];

            // Upload image
            $image =$_FILES['image']['name'];

            $target =$upload_dir . basename($image);
            move_uploaded_file($_FILES['image']['tmp_name'], $target);

            if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
                echo "<script>alert('invalid email');</script>";
            }else{
            $sql = "INSERT INTO students (name, email, phone, image, class_id) VALUES ('$name', '$email', '$phone', '$image', '$class_id')";
            if (mysqli_query($conn,$sql)) {
                $student_id=$conn->insert_id;

                $sql="INSERT INTO teacher_student (student_id,teacher_id) VALUES ('$student_id','$teacher_id')";
                $conn->query($sql);
                header("Location:students.php");
            }else{
                echo "Error: ". "<br>". mysqli_error($conn);
            }
        }
        }

        ?>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" >
            
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" required>

            <label for="image">image:</label>
            <input type="file" name="image" id="image" ><br>
            
            <label for="class_id">Class:</label>
            <select id="class_id" name="class_id" required>
                <option value="">Select Class</option>
                <?php while ($class = mysqli_fetch_assoc($classes)): ?>
                    <option value="<?= $class['id']; ?>"><?= $class['name']; ?></option>
                <?php endwhile; ?>
            </select>
            <label for="teacher_id">teacher:</label>
            <select id="teacher_id" name="teacher_id" required>
                <option value="">Select teacher</option>
                <?php while ($teacher = mysqli_fetch_assoc($teachers)): ?>
                    <option value="<?= $teacher['id']; ?>"><?= $teacher['name']; ?></option>
                <?php endwhile; ?>
            </select>
            <button type="submit">Add Student</button>
        </form>
    </div>
</body>
</html>
