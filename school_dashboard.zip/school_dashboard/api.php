<?php include 'dp.php'; 
header('Content-Type: application/json charset=utf-8');

if ($conn->connect_error){
    echo json_encode(["success"=>false,"massage"=>"connection failed: " . $conn->connect_error]);
    exit();
}

$sql = "SELECT * FROM teachers";
$result= $conn->query($sql);

$data=[];
if($result->num_rows > 0) {
    while($rows = $result->fetch_assoc()) {
        $data[]=$rows;
    }
    echo json_encode(["success"=>true,"data"=>$data]);
}else{
    echo json_encode(["success"=>false,"massage"=>"no records found"]);
}
$conn->close();
?>