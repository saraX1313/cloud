<!-- login  -->
<?php
include 'dp.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = htmlspecialchars($_POST['email']);
    $password =htmlspecialchars($_POST['password']);
    
    if (empty($email)||empty($password)) {
        echo "all fields are required";
    }else{
        //search for user
        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = $conn->query($sql);

        if ($result->num_rows >0) {
            $row = $result->fetch_assoc();

            if (password_verify($password, $row['password'])) {
                session_start();
                $_SESSION['user_id'] = $row['id'];
                echo "welcome". $row['name'];
            } else {
                echo "Invalid password";
            }
        }else{
        echo "email not found";
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet"  href="style.css">
</head>
<body>
<div class='sidebar'>
        <h1>school dashboard</h1>
        <ul>
            <li><a href="./Students/students.php">students</a></li>
            <li><a href="classes.php">classes</a></li>
            <li><a href="./Subject/subjects.php">subjects</a></li>
            <li><a href="./Teachers/teachers.php">teachers</a></li>
            <li><a href="login.php">login</a></li>
            <li><a href="register.php">regsiter</a></li>
        </ul>
    </div>
    <form action="" method="POST">
        <label for="email">EMAIL</label>
        <input type="text" name="email" id="email">
        <label for="password">Enter Password</label>
        <input type="text" name="password" id="password">
        <button type="submit">submit</button>
    </form>
</body>
</html>