<?php include '../dp.php'; 

$result= mysqli_query($conn,"
    SELECT  students.id , students.name, students.email, students.phone,students.image,
        classes.name AS class_name,
        teachers.name AS teacher_name
        FROM students
        JOIN classes ON students.class_id = classes.id
        JOIN teacher_student ON students.id = teacher_student.student_id
        JOIN teachers ON teacher_student.teacher_id =teachers.id
");

$upload_dir = "../uploads/";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Manage students</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        table {
            width: 80%;
            border-collapse: collapse;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f4f4f4;
        }
        form {
            width: 80%;
            margin: 20px auto;
            padding: 10px;
            border: 1px solid #ccc;
        }
        form label {
            display: inline-block;
            width: 150px;
        }
        form input, form button {
            margin: 5px 0;
        }
        .message {
            text-align: center;
            font-weight: bold;
        }
        i{
            cursor: pointer;
        }
    </style>

</head>
<body>
    <div class='sidebar'>
            <h1>school dashboard</h1>
            <ul>
                <li><a href="">students</a></li>
                <li><a href="../classes.php">classes</a></li>
                <li><a href="../Subjects/subjects.php">subjects</a></li>
                <li><a href="../Teachers/teachers.php">teachers</a></li>
            </ul>
        </div>
        <div class='content'>
        <h1 style="text-align: center;">Manage students</h1>
            <a href="students-add.php">add students</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>email</th>
                <th>phone</th>
                <th>image</th>
                <th>class</th>
                <th>teacher</th>
                <th>modify</th>
            </tr>
        </thead>
        <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)):?>
                <tr>
                    <td><?= ($row['id']); ?></td>
                    <td><?= ($row['name']); ?></td>
                    <td><?= ($row['email']); ?></td>
                    <td><?= ($row['phone']); ?></td>
                    <td>
                    <img src="<?= $upload_dir .$row['image']; ?>" alt="<?= htmlspecialchars($row['name']); ?>" style="width:50px; height:50px;">
                    </td>
                    <td><?= ($row['class_name']); ?></td>
                    <td><?= ($row['teacher_name']); ?></td>
                    <td>
                        <a href="students-edit.php?id=<?=$row['id'];?>">edit</a>
                        <a href="students-delete.php?id=<?=$row['id'];?>">delete</a>
                    </td>
                </tr>
                <?php endwhile;?>
        </tbody>
    </table>
    </div>   
</body>
</html>
